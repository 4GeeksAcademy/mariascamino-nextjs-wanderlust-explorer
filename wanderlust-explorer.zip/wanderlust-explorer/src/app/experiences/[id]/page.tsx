import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { EXPERIENCES_DATA } from "@/data/experiences";

export default async function ExperienceDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const experience = EXPERIENCES_DATA.find((exp) => exp.id === id);

  if (!experience) {
    notFound();
  }

  return (
    <div className="max-w-4xl mx-auto px-6 py-10">
      <Link href="/experiences" className="text-sm text-zinc-500 hover:text-zinc-900">
        ← Back to Explorer
      </Link>

      <div className="mt-4 relative h-80 w-full rounded-xl overflow-hidden">
        <Image
          src={experience.imageUrl}
          alt={experience.title}
          fill
          className="object-cover"
        />
      </div>

      <div className="mt-6 flex flex-col gap-3">
        <span className="inline-block w-fit bg-zinc-100 text-zinc-700 text-xs font-medium px-3 py-1 rounded-full">
          {experience.category}
        </span>
        <h1 className="text-3xl font-bold text-zinc-900">{experience.title}</h1>
        <p className="text-zinc-500">{experience.destination}</p>
        <div className="flex items-center gap-6 mt-2">
          <span className="text-lg font-semibold text-zinc-900">
            ${experience.price} / person
          </span>
          <span className="text-lg text-zinc-700">★ {experience.rating.toFixed(1)}</span>
        </div>
        <p className="mt-4 text-zinc-700 leading-relaxed">{experience.description}</p>
      </div>
    </div>
  );
}
