import Link from "next/link";

export default function Home() {
  return (
    <div className="flex flex-col flex-1 items-center justify-center min-h-[calc(100vh-4rem)] px-6 text-center bg-gradient-to-b from-zinc-50 to-white">
      <h1 className="text-4xl sm:text-5xl font-bold text-zinc-900 max-w-2xl">
        Discover experiences that change how you see the world
      </h1>
      <p className="mt-4 text-lg text-zinc-600 max-w-xl">
        Browse, search, filter, and save curated travel experiences from every
        corner of the planet.
      </p>
      <Link
        href="/experiences"
        className="mt-8 inline-flex items-center justify-center rounded-full bg-zinc-900 text-white px-8 py-3 font-medium hover:bg-zinc-700 transition-colors"
      >
        Explore Experiences
      </Link>
    </div>
  );
}
