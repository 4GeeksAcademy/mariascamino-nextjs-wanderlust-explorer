"use client";

import { CategoryType } from "@/types";

const CATEGORIES: CategoryType[] = ["Adventure", "Culture", "Food", "Wellness", "Nature"];

interface FilterBarProps {
  category: CategoryType | "";
  destination: string;
  destinations: string[];
  onCategoryChange: (value: CategoryType | "") => void;
  onDestinationChange: (value: string) => void;
  onReset: () => void;
}

export default function FilterBar({
  category,
  destination,
  destinations,
  onCategoryChange,
  onDestinationChange,
  onReset,
}: FilterBarProps) {
  return (
    <div className="flex flex-wrap items-center gap-3">
      <div className="flex flex-wrap gap-2">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => onCategoryChange(category === cat ? "" : cat)}
            className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-colors ${
              category === cat
                ? "bg-zinc-900 text-white border-zinc-900"
                : "bg-white text-zinc-700 border-zinc-300 hover:border-zinc-500"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <select
        value={destination}
        onChange={(e) => onDestinationChange(e.target.value)}
        className="rounded-full border border-zinc-300 px-3 py-1.5 text-sm bg-white"
      >
        <option value="">All destinations</option>
        {destinations.map((dest) => (
          <option key={dest} value={dest}>
            {dest}
          </option>
        ))}
      </select>

      {(category || destination) && (
        <button
          type="button"
          onClick={onReset}
          className="text-sm font-medium text-zinc-500 hover:text-zinc-900 underline"
        >
          Clear filters
        </button>
      )}
    </div>
  );
}
