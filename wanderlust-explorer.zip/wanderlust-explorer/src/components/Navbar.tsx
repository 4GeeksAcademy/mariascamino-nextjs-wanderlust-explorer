"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/experiences", label: "Explorer" },
  { href: "/favorites", label: "Favorites" },
  { href: "/profile", label: "Profile" },
];

export default function Navbar() {
  const pathname = usePathname();

  return (
    <header className="fixed top-0 left-0 right-0 z-50 h-16 bg-white/95 backdrop-blur border-b border-zinc-200">
      <nav className="max-w-6xl mx-auto h-full flex items-center justify-between px-6">
        <Link href="/" className="text-lg font-semibold text-zinc-900">
          Wanderlust Explorer
        </Link>
        <ul className="flex gap-6">
          {NAV_LINKS.map((link) => {
            const isActive = pathname === link.href;
            return (
              <li key={link.href}>
                <Link
                  href={link.href}
                  className={`text-sm font-medium pb-1 border-b-2 transition-colors ${
                    isActive
                      ? "text-zinc-900 border-zinc-900"
                      : "text-zinc-500 border-transparent hover:text-zinc-900"
                  }`}
                >
                  {link.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </header>
  );
}
